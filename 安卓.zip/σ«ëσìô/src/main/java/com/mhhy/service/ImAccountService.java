package com.mhhy.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mhhy.model.entity.ImAccountEntity;

public interface ImAccountService extends IService<ImAccountEntity> {
}
