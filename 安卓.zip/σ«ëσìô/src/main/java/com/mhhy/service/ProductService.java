package com.mhhy.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mhhy.model.entity.ProductEntity;

public interface ProductService extends IService<ProductEntity> {
}
