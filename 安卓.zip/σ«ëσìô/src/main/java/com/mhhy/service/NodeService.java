package com.mhhy.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mhhy.model.entity.NodeEntity;

public interface NodeService  extends IService<NodeEntity> {
}
