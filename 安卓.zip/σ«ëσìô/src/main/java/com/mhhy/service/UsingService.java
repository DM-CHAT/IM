package com.mhhy.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mhhy.model.entity.UsingEntity;

public interface UsingService extends IService<UsingEntity> {
}
