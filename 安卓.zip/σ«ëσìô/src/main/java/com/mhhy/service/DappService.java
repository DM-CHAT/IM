package com.mhhy.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mhhy.model.entity.DappEntity;

public interface DappService extends IService<DappEntity> {
}
