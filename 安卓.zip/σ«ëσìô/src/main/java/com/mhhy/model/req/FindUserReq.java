package com.mhhy.model.req;

import lombok.Data;

@Data
public class FindUserReq {
    String phoneOrEmail;
}
