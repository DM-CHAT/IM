package com.mhhy.model.resp;

import lombok.Data;

@Data
public class LoginResp {

    private String token;
}
