package com.mhhy.model.req;

import lombok.Data;

@Data
public class ReqBase {
    private String data;
}
