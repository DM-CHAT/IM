package com.mhhy.model.req;

import lombok.Data;

@Data
public class NodeRegisterReq {

    private String data;

}
