package com.mhhy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mhhy.model.entity.ImAccountEntity;

public interface ImAccountMapper extends BaseMapper<ImAccountEntity> {
}
