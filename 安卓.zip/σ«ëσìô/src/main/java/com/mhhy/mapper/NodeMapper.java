package com.mhhy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mhhy.model.entity.NodeEntity;

public interface NodeMapper extends BaseMapper<NodeEntity> {
}
