package com.mhhy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mhhy.model.entity.DappEntity;

public interface DappMapper extends BaseMapper<DappEntity> {
}
