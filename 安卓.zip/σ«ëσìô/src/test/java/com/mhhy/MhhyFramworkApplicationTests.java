package com.mhhy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MhhyFramworkApplicationTests {

    @Test
    void contextLoads() {
    }

}
